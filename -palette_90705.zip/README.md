# PalletMaster
discordを用いてクトゥルフ神話TRPGを行う際に、PLのプレイにおいて便利なアプリです。

## 概要
1. discord上でクトゥルフ神話TRPGをやる際に利用するアプリ
2. web上で作成したキャラシートのデータをまとめることができる
  - 対応サイト
    1. [キャラクター保管所 
](https://charasheet.vampire-blood.net/)
    2. [TRPGキャラクターシート アーカイブス
](http://chara.revinx.net/)
3. ダイスbotにダイスを振らせることができる文章をクリップボードにコピーする
4. webhookを作成した場合、アプリ上からdiscordに文章を出力することができる
5. BCDice-APIのURLを設定した場合、アプリ上でダイスを振ることができる